#!/usr/bin/env python
# -*- coding: utf-8 -*-

# print 'net@net.net'.encode('base64', 'strict')
# print 'bmV0QG5ldC5uZXQ='.decode('base64', 'strict')

import os
import sys
import json
import socket
from time import sleep
from threading import Thread
from datetime import datetime
import xbmc, xbmcgui, xbmcaddon

dt = datetime.today()
#d = datetime.today() # Uhrzeit fehlt noch
#str(d.strftime('%d.%m.%y'))


__author__ = 'harryberlin/n3mesis'

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')

ICON = os.path.join(ADDONPATH, 'icon.png')



#Kilometerstand aus dem Kombi abfragen mit TCP, wird in der Funktion "get_odometer()" aufgerufen
def send_tcp_command(message):
    clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # ok
    clientsocket.settimeout(1)  # ok
    
    port = 8089
    try:
        clientsocket.connect(('localhost', port))  # 127.0.0.1 ok
    except:
        raise ValueError

    clientsocket.send(message)  # obc;get;odometer #ok
    #sleep(0.2)

    clientsocket.settimeout(1)  # auf antwort warten ok

    #sleep(0.2)

    clientsocket.settimeout(1)  # ok
    clientsocket.shutdown(True)  # ok
    #data = 1
    data = clientsocket.recv(2048).replace('\n', '')  # antwort nicht groesser 50 nicht weniger 50 ok
    #clientsocket.close()
    return data

global result
result = json.loads(send_tcp_command('OBC;GET'))

#Ruft Kilometerstand ab
def get_odometer(): #int(get_odometer())
    global result
    #try:
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['odometer']
    #except ValueError:
     #   odometer = -1

    #if odometer < 0:
    #    xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (odometer)) #ok

    #    return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    #else:
    return str(odometer) #ok	
		
#Ruft die Temperatur der Kühlflüssigkeit ab ab
def get_coolant(): #int(get_odometer())
    global result
    """try:
        coolant = str(send_tcp_command('OBC;GET;coolant')) #ok
    except ValueError:
        coolant = -1

    if coolant < 0:
        xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (coolant)) #ok
		
        return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['coolant_c']
    return str(odometer) #ok
		
#Ruft die Temperatur der Kühlflüssigkeit ab ab
def get_outtemp(): #int(get_odometer())
    global result
    """try:
        outtemp = str(send_tcp_command('OBC;GET;outtemp')) #ok
    except ValueError:
        outtemp = -1

    if outtemp < 0:
        xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (outtemp)) #ok
		
        return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['outtemp']
    return str(odometer) #ok
		
#Ruft die Temperatur der Kühlflüssigkeit ab ab
def get_range(): #int(get_odometer())
    global result
    """try:
        range = str(send_tcp_command('OBC;GET;range')) #ok
    except ValueError:
        range = -1

    if range < 0:
        xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (range)) #ok
		
        return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['range']
    return str(odometer) #ok
		
#Ruft die Temperatur der Kühlflüssigkeit ab ab
def get_fuel_level(): #int(get_odometer())
    global result
    """try:
        fuel = str(send_tcp_command('OBC;GET;fuel_level')) #ok
    except ValueError:
        fuel = -1

    if fuel < 0:
        xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (fuel)) #ok
		
        return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['fuel_level']
    return str(odometer) #ok
	
#Verbrauch_1 aus dem BC
def get_cons(): #int(get_odometer())
    global result
    """try:
		cons = str(send_tcp_command('OBC;GET;consumption1')) #ok
    except ValueError:
        cons = -1

    if cons < 0:
		xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (cons)) #ok
		
		return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
    odometer = result['IBusCommunicator']['consumption1']
    return str(odometer) #ok
		
#Handbrake
#def get_handbrake(): #int(get_odometer())
    """try:
        hb = str(send_tcp_command('OBC;GET;gm_states')) #ok
    except ValueError:
        hb = -1

    if hb < 0:
        xbmc.executebuiltin('Notification(ERROR:, TCP returns: %s)' % (hb)) #ok
		
        return 0 # Um zu verhindern das er Quatsch in die variable schreibt, dummywert
    else:"""
    #result = json.loads(send_tcp_command('OBC;GET'))
#    odometer = result['IBusCommunicator']['ike_states']['handbrake']
#    return str(odometer) #ok
		#Über Handbremse und ZV Zustand den SleepTimer triggern?
		
def log(message):
    xbmc.log('plugin.script.logmailer: %s' % message, xbmc.LOGNOTICE)


def note(heading, message=None, time=5000):
    xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2=None, label3=None):
    log('DIALOG_OK: "%s%s%s"' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''))
    xbmcgui.Dialog().ok('Log Mailer', label1, label2, label3)


def get_addon_setting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    if setting.upper() == 'TRUE': return True
    if setting.upper() == 'FALSE': return False
    return '%s' % setting


def open_settings():
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def send_logfile():
    #result = json.loads(send_tcp_command('OBC;GET'))
    progress = xbmcgui.DialogProgressBG()
    progress.create('Log Mailer','Load Settings...')

    import time
    import smtplib
    import zipfile
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email.mime.multipart import MIMEMultipart
    from email import encoders

    # eMail-Adressen (Sender/Empfaenger)
    mailSender = get_addon_setting('mail_adress')
    if mailSender == '':
        dialog_ok('Setting Error', 'E-Mail Adress is missing')
        return
    log('Sender: %s' % mailSender)

    log_mode = get_addon_setting('mail_log_mode')
    if log_mode == '0':
        Hostname = "BMWRaspControl"
        mailReceiver = get_addon_setting('recv_mail_adress') #'net@net.net'
        full_file_path = ''
    elif log_mode == '1':
        Hostname = "IBusCommunicator"
        mailReceiver = get_addon_setting('recv_mail_adress') #'ZGVidWcuaWJ1c2NvbW11bmljYXRvckBnbXguZGU='.decode('base64', 'strict')
        full_file_path = '/home/osmc/.kodi/temp/kodi.log' #wieder aktivieren NUR LINUX, OSMC, sollte umgestellt werden auf dynamisch os.path.join()
    else:
        return
    log('Receiver: %s' % mailReceiver)

    msg = MIMEMultipart()
    msg['Subject'] = "%s LogFile-Export" % Hostname
    msg['From'] = mailSender
    msg['To'] = mailReceiver

    smtpHost = get_addon_setting('mail_out_server')
    if smtpHost == '':
        dialog_ok('Setting Error', 'SMTP Server is missing')
        return
    log('SMTP Host: %s' % smtpHost)

    smtpSecureMode = get_addon_setting('mail_out_secure')
    if smtpSecureMode == '1':
        smtpPort = int(get_addon_setting('mail_out_ssl_port'))
    else:
        smtpPort = int(get_addon_setting('mail_out_port'))
    log('SMTP Port: %s' % smtpPort)

    progress.update(10,'Connecting Server...')

    log('SMTP Server connecting...')
    log('SMTP Host: %s, Port: %s, SSL: %s' % (smtpHost, smtpPort, 'Yes' if smtpSecureMode == '1' else 'No'))
    try:
        if smtpSecureMode == '1':
            server = smtplib.SMTP_SSL(timeout=3)
            log('SSL Connection')
        else:
            server = smtplib.SMTP(timeout=3)
        server.connect(smtpHost, smtpPort)

    except smtplib.socket.error:
        dialog_ok('Connection Error','Host: %s, Port: %s, SSL: %s' % (smtpHost, smtpPort, get_addon_setting('mail_ssl')))
        return

    server.ehlo_or_helo_if_needed()
    if smtpSecureMode == '2':
        server.starttls()  # If TLS authentication is not required set a hash at the beginning of this line
        log('STARTTLS is True')

    server.ehlo_or_helo_if_needed()

    # SMTP-Ausgangsserver (Sender)
    smtpUser = get_addon_setting('mail_out_user')
    if smtpUser == '':
        dialog_ok('Setting Error', 'Login Name is missing')
        return
    log('SMTP User: %s' % smtpUser)

    smtpPassword = get_addon_setting('mail_out_password')
    if smtpPassword == '':
        log('SMTP Password not stored. Ask User for Input')
        password = xbmcgui.Dialog().input('%s password:' % smtpUser, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if password != '':
            smtpPassword = password
        else:
            dialog_ok('no password entered')
            return

    server.login(smtpUser, smtpPassword)
    log('SMTP Server connected')
    progress.update(30, 'Server connected')
	
    progress.update(50, 'Prepare E-Mail...')
    ###############################################################################
    # Time/Date Recording for Filename
    fndate = "%04i%02i%02i" % (int(time.localtime()[0]), int(time.localtime()[1]), int(time.localtime()[2]))
    fntime = "%02i%02i%02i" % (int(time.localtime()[3]), int(time.localtime()[4]), int(time.localtime()[5]))
	
    MailContent = "BMW RetroConnectedDrive: " +\
	"\n" + "\n" +\
	"Datum: " + dt.strftime("%d.%m.%y") + "\n" +\
	"Uhrzeit: " + dt.strftime("%H:%M")  + " Uhr" + "\n" +\
	"Außentemperatur: " + str(get_outtemp()) + " °C" +\
	"\n" + "\n" + \
	"Laufleistung: " + str(get_odometer()) + " km" + "\n" +\
	"Temperatur Kühlflüssigkeit: " + str(get_coolant()) + " °C" + "\n" +\
	"Verbrauch (BC): " + str(get_cons()) + " L / 100 km" + "\n" +\
	"Reichweite: " + str(get_range()) + " km" + "\n" +\
	"Tankinhalt: " + str(get_fuel_level()) + " L" + "\n" +\
	"\n" + "\n" + "\n" +\
	"Die exportierten LogFiles befinden sich im Anhang dieser eMail." + "\n" + "\n" +\
	"__________________________" + "\n" +\
	"Es handelt sich hierbei um eine automatisch generierte E-Mail, die von Ihrem Raspberry Pi (" + Hostname + ") gesendet worden ist."
	
	#MailContent = "BMW ConnectedDriveRetro: " + "\n" + "\n" + "Datum: " + dt.strftime("%d.%m.%y") +  "\n" + "Uhrzeit: " + dt.strftime("%H:%M") + " Uhr" + "\n" + "Außentemperatur: " + str(get_outtemp()) + " km" + "\n" + "\n" + "Laufleistung: " + str(get_odometer()) + " km" + "\n" + "Temperatur Kühlflüssigkeit: " + str(get_coolant()) + " °C" + "\n" + "Verbrauch (BC): " + str(get_cons()) + " L / 100 km" + "\n" + "Reichweite: " + str(get_range()) + " L / 100 km" + "\n" + "Tankinhalt: " + str(get_fuel_level()) + " L" + "\n" + "\n" + "\n" + "Die exportierten LogFiles befinden sich im Anhang dieser eMail. " + "\n" + "\n" + "__________________________" + "\n" + "Es handelt sich hierbei um eine automatisch generierte E-Mail, die von Ihrem Raspberry Pi (" + Hostname + ") gesendet worden ist."
    msg.attach(MIMEText(MailContent, 'plain'))

    filename = "Log-Export_" + Hostname + "_" + fndate + "_" + fntime + ".zip"

    progress.update(60, 'Prepare E-Mail Attachments...')
    log('create zip file')
    zip = zipfile.ZipFile(os.path.join(ADDONPATH, filename), 'w', zipfile.ZIP_DEFLATED) 	#wieder aktivieren nur Linux
    zip.write(full_file_path,os.path.split(full_file_path)[1]) 							#wieder aktivieren
    zip.close() 																			#wieder aktivieren


    log('open file for mail')
    attachment = open(os.path.join(ADDONPATH, filename), "rb") 							#wieder aktivieren

    part = MIMEBase('application', 'octet-stream')
    log('read file %s' % filename)
    part.set_payload(attachment.read()) 													#wieder aktivieren
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    msg.attach(part)
    #try:
    progress.update(75, 'Send E-Mail...')
    log('send mail')
    server.sendmail(mailSender, mailReceiver, msg.as_string())
    note('E-Mail sent successfull')
    #except:
    #    dialog_ok('Error: E-Mail not sent')
    server.quit()
    progress.update(99, 'E-Mail sent')

    log('delete zip file')
    progress.update(100, 'Delete Tempfile')
    time.sleep(1)
    if os.path.isfile(os.path.join(ADDONPATH, filename)):
        os.remove(os.path.join(ADDONPATH, filename))

    progress.close()


def main():
    #count = len(sys.argv) - 1
    #if count > 0:
    #    given_args = sys.argv[1].split(';')
    #    if str(given_args[0]) == "send_logfile":
    #        send_logfile()
    #    elif str(given_args[0]) == "settings":
    #        open_settings()
    #    else:
    #        note('Unknown Arguments given!')
	send_logfile()
    #else:
    #    open_settings()


if __name__ == '__main__':
    main()
